#include "ProfileData.h"
#include <arduino.h>

ProfileData::ProfileData() : thresholds_{{0, 0},{1, 0},{2, 0}} {};

void ProfileData::editProfile(int key, double threshold) {
  thresholds_[key] = threshold;
}

double ProfileData::getThreshold(int key) {
  return thresholds_[key];
}