#pragma once

class SetPMS {
public:
void updateThresholds();
};

extern SetPMS setPMS;