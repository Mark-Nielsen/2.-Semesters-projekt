#include "PowerSensor.h"
#include "PMScontrol.h"
#include "InitPMS.h"
#include "SetPMS.h"
#include "ProfileData.h"
#include "TerminatePMS.h"

// Opretter alle vores objekter (Globalt)
IRsensor sensor;
InitPMS initiator;
PMScontrol controller;
ProfileData profileData;
TerminatePMS terminator;
SetPMS setPMS;
PowerSensor powerMonitor(50); // parameter er batteri kapacitet i mAh

void setup() {
    Serial.begin(115200);
    pinMode(2, INPUT_PULLDOWN);
}

void loop() {
    while(1) { // venter på system skal aktiveres
        int powerDraw;
        powerDraw = powerMonitor.getPowerDraw();
        if(powerDraw > 600) {
            break;
        }
        delay(1000);
    }

    if (powerMonitor.unitTestPowerSensorLower() && powerMonitor.unitTestPowerSensorUpper()) {
        initiator.setupHardware(sensor, powerMonitor.emergencyPowerNeeded());
        initiator.calibrate(sensor);
    } else {
        initiator.messageFail();
        initiator.systemReady = false;
        while(1) {}
    }

    while(powerMonitor.emergencyPowerNeeded()) {
        // Run the control logic
        controller.process(sensor, initiator, powerMonitor);
        delay(200);    
    } 

    if (!powerMonitor.emergencyPowerNeeded()) {
        terminator.powerDown(initiator);
    }
    
}