#pragma once
#include "InitPMS.h"
class TerminatePMS {
public:
void powerDown(InitPMS &config);
};

