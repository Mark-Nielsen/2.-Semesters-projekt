#pragma once
#include <Adafruit_MLX90640.h>
#include <Wire.h>
#include "IRsensor.h"
#include <LittleFS.h>



class InitPMS {
private:
    const char* CALIB_FILE = "/bg_kalibrering.bin";

    bool loadBackground() {
    if (!LittleFS.exists(CALIB_FILE)) {
        return false;
    }

    File file = LittleFS.open(CALIB_FILE, FILE_READ);
    if (!file) {
        return false;
    }

    file.read((uint8_t*)backgroundFrames, sizeof(backgroundFrames));
    file.close();
    return true;
    }


    void saveBackground() {
    File file = LittleFS.open(CALIB_FILE, FILE_WRITE);
    if (!file) {
        return;
    }

    file.write((uint8_t*)backgroundFrames, sizeof(backgroundFrames));
    file.close();
    
    }

public: 
    const int RELAY_PINS[3] = {17, 25, 26};
    float backgroundFrames[3][768]; 
    bool isCalibrated[3] = {false, false, false};
    bool systemReady = false;
    bool initOn_ = false;

    IRsensor sensor[3];




void tcaselect(uint8_t i) {
    if (i > 7) return;
    Wire.beginTransmission(0x70);
    Wire.write(1 << i);
    Wire.endTransmission();
}

void setInitOn(bool status) {
    initOn_ = status;
}

void setupHardware(IRsensor &sensoren, bool check) {
    if (check && !initOn_) {        
        for (int i = 0; i < 3; i++) {
            pinMode(RELAY_PINS[i], OUTPUT);
            digitalWrite(RELAY_PINS[i], LOW);
            Wire.begin(21, 22);
            Wire.setClock(100000);
            int fail_count = 0;
            for (uint8_t i = 0; i < 3; i++) {
                tcaselect(i);
                delay(10);
                if (!sensoren.begin(MLX90640_I2CADDR_DEFAULT, &Wire)) {
                    Serial.println("sensor");
                    fail_count++;
                } else {
                    sensoren.setMode(MLX90640_CHESS);
                    sensoren.setRefreshRate(MLX90640_4_HZ);
                }
            }
            if(fail_count == 3) {
                systemReady = false;
                messageFail();
                while (1) {};      
            } else {
                systemReady = true;
            }
            for (int i = 0; i < 3; i++) {
                sensor[i].init(i, backgroundFrames[i]);
            }
            setInitOn(true);
            systemReady = true;
        }
        if (systemReady) {
            messageSuccess();
        }
    }
}


void calibrate(IRsensor &sensoren) {
    if (Serial.available() > 0) {
        String key = Serial.readString();
        if (key == "reset\n" || key == "Reset\n" || key == "RESET\n") {
            LittleFS.remove(CALIB_FILE);
            isCalibrated[0] = false;
            isCalibrated[1] = false;
            isCalibrated[2] = false;
        }
    }
        if (!LittleFS.begin(true)) { 
        } else {
            if (loadBackground()) {
            isCalibrated[0] = true;
            isCalibrated[1] = true;
            isCalibrated[2] = true;
            }
        }
        float tempFrame[768];
        for (uint8_t i = 0; i < 3; i++) {
            if (isCalibrated[i]) continue; // Skip if already done
            tcaselect(i);
            delay(500);
            while (sensoren.getFrame(tempFrame) != 0) {
                delay(50);
            }
            for (int p = 0; p < 768; p++) {
                backgroundFrames[i][p] = tempFrame[p];
            }
            saveBackground();
            isCalibrated[i] = true;
        }
    }
void messageSuccess() {
    Serial.println("ok");
}


void messageFail() {
    Serial.println("fejl");
}



};