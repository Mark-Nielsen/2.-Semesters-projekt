#pragma once

class PowerSensor {
public:
  PowerSensor(double capacity_);
  bool unitTestPowerSensorLower();
  bool unitTestPowerSensorUpper();
  double getPowerDraw();
  void updateCapacity();
  double getCapacityPct();
  bool emergencyPowerNeeded();
  void resetCapacity();

private:
  double capacity_; 
  int lastUpdateMs_;
  double startCapacity_;
  double capacityPct_;
};

extern PowerSensor powerMonitor;