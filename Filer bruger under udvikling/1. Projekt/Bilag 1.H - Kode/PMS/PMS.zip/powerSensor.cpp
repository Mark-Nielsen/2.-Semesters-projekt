#include "powerSensor.h"
#include <Arduino.h>

namespace {
static int kAdcZero = 3040; // Updateres i unit test lower. Værdi hvor maks 3% ADC målinger ryger over ved ingen rum aktive.
static int kAdcFull = 3170; // Updateres i unit test upper. Værdi hvor maks 3% ADC målinger falder under ved alle rum aktive.
constexpr int kFullScale_mA = 800; // Hard coded udfra maks strøm fra spændings generator.
constexpr int kSamples = 20; // Antal målinger avg ADC beregninger
constexpr double kMsPerHour = 3600000.0;
} 

PowerSensor::PowerSensor(double capacity_mAh) : capacity_(capacity_mAh), lastUpdateMs_(millis()), startCapacity_(capacity_mAh) {
  analogReadResolution(12);
}

bool PowerSensor::unitTestPowerSensorLower() { // tester ADC læsning ved ingen rum aktive. 
  int lowerBoundary{3000}; // gæt på værdi er markant under maksimale ADC måling.
  int attempts{0};

  // Slukker alle rum, ved at aktivere 
   // Skal bruges til slukke PMS, når strøm net er tilbage
  pinMode(17, OUTPUT);
  pinMode(25, OUTPUT);
  pinMode(26, OUTPUT);
  digitalWrite(17, HIGH);
  digitalWrite(25, HIGH);
  digitalWrite(26, HIGH);

  delay(3000); // Delay så strøm når at falde i systemet.
  while(1) {
    int outliers{0};
    for (int i = 0; i < 200; i++) {
      int sum{0};
      for (int j = 0; j < kSamples; j++) {
        sum += analogRead(36);
      }
      int avg = sum / kSamples;
      if(avg > lowerBoundary) {
        outliers++;
      }
    }

    if (outliers >= 6) {
      attempts++;
      lowerBoundary++;
    } else {
      kAdcZero = lowerBoundary;
      return true;
    }
    if (attempts >= 100) { // Fail safe
      return false;
    }
  }
}

bool PowerSensor::unitTestPowerSensorUpper() { // tester ADC læsning ved alle rum aktive. 
  int upperBoundary{3300}; // gæt på værdi er markant over maksimale ADC måling.
  int attempts{0};

  // aktivere alle rum
  digitalWrite(17, LOW);
  digitalWrite(25, LOW);
  digitalWrite(26, LOW);

  while(1) {
    int outliers{0};
    for (int i = 0; i < 200; i++) {
      int sum{0};
      for (int j = 0; j < kSamples; j++) {
        sum += analogRead(36);
      }
      int avg = sum / kSamples;
      if(avg < upperBoundary) {
        outliers++;
      }
    }
    if (outliers >= 6) {
      attempts++;
      upperBoundary--;
    } else {
      kAdcFull = upperBoundary;
      lastUpdateMs_ = millis();
      return true;
    }
    if (attempts >= 100) { // Fail safe
      return false;
    }
  }
}



double PowerSensor::getPowerDraw() {
  int sum = 0;
  for (int i = 0; i < kSamples; i++) {
    sum += analogRead(36);
  }

  int avg = sum / kSamples;
  if (avg <= kAdcZero) {
    return 0;
  }

  int span = kAdcFull - kAdcZero;
  if (span <= 0) {
    return 0;
  }

  double delta = avg - kAdcZero;
  double current_mA = (delta * kFullScale_mA) / span;
  if (current_mA < 0) {
    current_mA = 0;
  }
  if (current_mA > kFullScale_mA) {
    current_mA = kFullScale_mA;
  }

  return current_mA;
}

void PowerSensor::updateCapacity() {
  double now = millis(); // millis returnere antal milisekunder siden programmet startede.
  double elapsedMs = now - lastUpdateMs_;
  lastUpdateMs_ = now;

  double current_mA = getPowerDraw();
  double draw = (double)current_mA * (double)elapsedMs / kMsPerHour;

  if (capacity_ <= 0) {
    return;
  }

  if (draw >= capacity_) {
    capacity_ = 0.0;
    return;
  }
  capacity_ -= draw;
  capacityPct_ = capacity_/startCapacity_*100;
}

bool PowerSensor::emergencyPowerNeeded() {
  return digitalRead(2);
}

double PowerSensor::getCapacityPct() {
  return capacityPct_;
}

void PowerSensor::resetCapacity() {
  capacity_ = startCapacity_;
}