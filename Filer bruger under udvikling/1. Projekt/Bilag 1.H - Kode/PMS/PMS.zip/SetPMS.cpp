#include "SetPMS.h"
#include "ProfileData.h"
#include <arduino.h>

void SetPMS::updateThresholds() { // Tager strings på form "Profile 1|0,0,0\n"
    if (!Serial.available()) return;

    String line = Serial.readStringUntil('\n');
    if (!line.startsWith("Profile ")) return;

    int separator = line.indexOf('|');
    if (separator == -1) return; // separator bliver -1, hvis der ikke er nogen | i strengen.

    int profileNum = line.substring(8, separator).toInt();
    if (profileNum < 1 || profileNum > 5) return; // Validér profilnummer

    String values = line.substring(separator + 1);

    int firstComma  = values.indexOf(',');
    int secondComma = values.indexOf(',', firstComma + 1);

    String val0 = values.substring(0, firstComma);
    String val1 = values.substring(firstComma + 1, secondComma);
    String val2 = values.substring(secondComma + 1);

    profileData.editProfile(0, val0.toFloat());
    profileData.editProfile(1, val1.toFloat());
    profileData.editProfile(2, val2.toFloat());
}