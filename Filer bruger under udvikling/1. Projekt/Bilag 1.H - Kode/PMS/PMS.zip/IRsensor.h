#pragma once
#include <Adafruit_MLX90640.h>


class IRsensor : public Adafruit_MLX90640 {     // Nedarvning! Det betyder at et IRsensor objekt også indeholder metoderne fra Adafruit biblioteket.
  private:
    bool activity_;
    const float TEMP_THRESHOLD = 3.0;
    const float MIN_HUMAN_TEMP = 30.0;
    const int MIN_CLUSTER_SIZE = 12;

    int id_;
    float* backgroundFrame_; // Pointer: Kigger over på arrayet inde i InitPMS

  public:

    // Empty constructor
    IRsensor();

    void init(int id, float* bgFrame);

    // IRsensors only detect if initOn is true. Checks the temperature of the pixels by comparing the current frame to the background frame and then concludes if there is a person in the room
    bool getActivity(float* current, bool initOn);
};