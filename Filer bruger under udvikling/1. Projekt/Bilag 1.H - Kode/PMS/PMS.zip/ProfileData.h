#pragma once

#include <map>

class ProfileData {
public:
  ProfileData();
  void editProfile(int key, double threshold);
  double getThreshold(int key);

private:
    std::map<int, double> thresholds_;
};

extern ProfileData profileData; // skal være her så den er global avalible. Ellers kan vi ikke bruge den i indstilPMS