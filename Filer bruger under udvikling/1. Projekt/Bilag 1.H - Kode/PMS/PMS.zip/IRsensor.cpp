#include "IRsensor.h"

  // Empty constructor
  IRsensor::IRsensor() {};


void IRsensor::init(int id, float* bgFrame) {
  id_ = id;
  backgroundFrame_ = bgFrame;
}

// IRsensors only detect if initOn is true. Checks the temperature of the pixels by comparing the current frame to the background frame and then concludes if there is a person in the room
bool IRsensor::getActivity(float* current, bool initOn) {
      if (initOn) {     // Bemærk! I PMScontrol bliver denne parameter (initOn) til initOn_ attributten fra InitierPMS. Derfor er InitierPMS klassen ikke inkluderet i IRsensor.cpp
        int count = 0;
        for (int y = 1; y < 23; y++) {
            for (int x = 1; x < 31; x++) {
              int p = y * 32 + x;
              if ((current[p] - backgroundFrame_[p]) > TEMP_THRESHOLD && current[p] > MIN_HUMAN_TEMP) {
                  int neighbors = 0;
                  if ((current[p-1] - backgroundFrame_[p-1]) > (TEMP_THRESHOLD * 0.8)) neighbors++;
                  if ((current[p+1] - backgroundFrame_[p+1]) > (TEMP_THRESHOLD * 0.8)) neighbors++;
                  if ((current[p-32] - backgroundFrame_[p-32]) > (TEMP_THRESHOLD * 0.8)) neighbors++;
                  if ((current[p+32] - backgroundFrame_[p+32]) > (TEMP_THRESHOLD * 0.8)) neighbors++;

                  if (neighbors >= 2) count++;
              }
            }
        }
        activity_ = (count >= MIN_CLUSTER_SIZE);
        return activity_;

      } else {

        return false;

      }
    }