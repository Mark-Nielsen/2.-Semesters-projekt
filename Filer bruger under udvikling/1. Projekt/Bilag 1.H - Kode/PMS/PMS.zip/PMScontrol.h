#pragma once
#include "powerSensor.h"
#include <Adafruit_MLX90640.h>
#include "InitPMS.h"
#include "IRsensor.h"
#include "ProfileData.h"
#include "PowerSensor.h"
#include "SetPMS.h"

class PMScontrol {
    private:
        bool relayState[3] = {true, true, true}; 
        
    public:
        void process(IRsensor &sensoren, InitPMS &config, PowerSensor &powerSensor) {
            if (!config.systemReady) return;

            double currentCapacity = powerSensor.getCapacityPct();
            float mlxFrame[768];

            for (uint8_t i = 0; i < 3; i++) {
                if (!config.isCalibrated[i]) continue; 

                config.tcaselect(i);
                if (sensoren.getFrame(mlxFrame) != 0) continue;

                bool targetRelayState = config.sensor[i].getActivity(mlxFrame, config.initOn_);

                if (currentCapacity < profileData.getThreshold(i)) {
                    targetRelayState = false;
                }

                bool currentRelayState = relayState[i];

                if (targetRelayState != currentRelayState) {
                    digitalWrite(config.RELAY_PINS[i], targetRelayState ? LOW : HIGH);

                    relayState[i] = targetRelayState;
                }
            }
            powerMonitor.updateCapacity();
            setPMS.updateThresholds();
            // Sender updateret capacitet til raspberry
            Serial.println((int)powerMonitor.getCapacityPct());
            delay(50);
        }
};