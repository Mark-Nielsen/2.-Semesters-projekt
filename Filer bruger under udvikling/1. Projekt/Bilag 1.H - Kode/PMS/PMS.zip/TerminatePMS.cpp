#include "InitPMS.h"
#include "TerminatePMS.h"
#include "PowerSensor.h"

void TerminatePMS::powerDown(InitPMS &config){
  config.setInitOn(false);
  config.systemReady = false;
  for (int i = 0; i < 3; i++) {
        digitalWrite(config.RELAY_PINS[i], LOW);
    }
    powerMonitor.resetCapacity();
    Serial.println((int)100);
    Serial.println("idle");
    
}

