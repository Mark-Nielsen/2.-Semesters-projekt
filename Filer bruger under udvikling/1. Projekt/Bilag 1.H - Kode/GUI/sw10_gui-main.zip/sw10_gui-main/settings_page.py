import tkinter as tk
import Init
from tkinter import *

powerdown_entry=tk.StringVar()

def settings_page():
    settings_frame = tk.Frame(Init.main_frame, bg='#DFEAD6')
    settings_frame.pack(fill="both", expand=True)

    label = tk.Label(
        settings_frame,
        text="Management",
        font=('Arial', 20, 'bold'),
        bg='#DFEAD6'
    )
    label.pack(pady=20)

    #-----User input-----
    user_label = tk.Label(
        settings_frame,
        text="Seconds before power out",
        font=('Arial', 12, 'bold'),
        bg='#DFEAD6',
        fg='#41431B',
        height=4,
        anchor="w"
    )
    user_label.pack()
    
    seconds_entry = tk.Scale( settings_frame, variable = powerdown_entry, 
            from_ = 5, to = 600, length=200,  
            orient = HORIZONTAL, bg="#DFEAD6")  
    seconds_entry.pack()