import tkinter as tk
import Init

#----PopupWindow----
SuccessfulBoot = True    #successfull bool skal her ændres baseret på hardware test input
def SystemBootPopup():
    PopupWindow = tk.Toplevel(Init.root)
    PopupWindow.attributes('-topmost', True)
    PopupWindow.attributes('-fullscreen', True)
    PopupWindow.geometry('800x500')
    PopupWindow.title('System Boot')
    PopupWindow.configure(background='#DFEAD6')
    PopupLabel = tk.Label(
        PopupWindow,
        font=('Arial', 36),
        bg='#DFEAD6',
        fg='black'
    )
    PopupLabel2 = tk.Label(
        PopupWindow,
        font=('Arial', 18),
        bg='#DFEAD6',
        fg='#43431B'
    )
    if SuccessfulBoot:
        PopupLabel.configure(text='System booted successfully')
        PopupLabel2.configure(text='Closing window automatically in 5 seconds')
    else:
        PopupLabel.configure(text='System boot failed')
        PopupLabel2.configure(text='Contact system maintenance about hardware issues')
    PopupLabel.pack(padx = 75, pady = 75)
    PopupLabel2.pack(padx = 50, pady = 50)
    PopupButton = tk.Button(PopupWindow, text="OK", command=PopupWindow.destroy)
    PopupButton.configure(font=('Arial', 24))
    PopupButton.pack(padx = 40, pady = 40)
    if SuccessfulBoot:
        PopupWindow.after(5000, PopupWindow.destroy)   #lukker popup efter 5 sek. Hvis successfull


#----PopupWindow_PMS_Shutdown----
NormalPowerActive = True    #successfull bool skal her ændres baseret på hardware test input
def SystemShutdownPopup():
    PopupWindow = tk.Toplevel(Init.root)
    PopupWindow.attributes('-topmost', True)
    PopupWindow.geometry('800x500')
    PopupWindow.title('System turn off')
    PopupWindow.configure(background='#DFEAD6')
    PopupLabel = tk.Label(
        PopupWindow,
        font=('Arial', 36),
        bg='#DFEAD6',
        fg='black'
    )
    PopupLabel2 = tk.Label(
        PopupWindow,
        font=('Arial', 18),
        bg='#DFEAD6',
        fg='#43431B'
    )
    if NormalPowerActive:
        PopupLabel.configure(text='Power has returned to building')
        PopupLabel2.configure(text='PMS is turned off')
        PopupLabel.pack(padx = 75, pady = 75)
        PopupLabel2.pack(padx = 50, pady = 50)
        PopupButton = tk.Button(PopupWindow, text="OK", command=PopupWindow.destroy)
        PopupButton.configure(font=('Arial', 24))
        PopupButton.pack(padx = 40, pady = 40)
        
        
#----PopupWindow_PMS_SensorFail----
#NormalPowerActive = True    
def SensorFail():
    PopupWindow = tk.Toplevel(Init.root)
    PopupWindow.attributes('-topmost', True)
    PopupWindow.geometry('800x500')
    PopupWindow.title('Sensor Fail')
    PopupWindow.configure(background='#DFEAD6')
    PopupLabel = tk.Label(
        PopupWindow,
        font=('Arial', 36),
        bg='#DFEAD6',
        fg='black'
    )
    PopupLabel2 = tk.Label(
        PopupWindow,
        font=('Arial', 18),
        bg='#DFEAD6',
        fg='#43431B'
    )
    if NormalPowerActive:
        PopupLabel.configure(text='A sensor is off or not working')
        PopupLabel2.configure(text='System still running')
        PopupLabel.pack(padx = 75, pady = 75)
        PopupLabel2.pack(padx = 50, pady = 50)
        PopupButton = tk.Button(PopupWindow, text="OK", command=PopupWindow.destroy)
        PopupButton.configure(font=('Arial', 24))
        PopupButton.pack(padx = 40, pady = 40)