import serial
import Init
import home_page
import Popup

# Serial setup
ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)
ser.dtr = False 
ser.rts = False

#Read serial:
def read_serial():

    while True:
        try:
            line = ser.readline().decode('utf-8').strip()
            if line.isdigit():
                Init.root.after(0,home_page.update_power_callback, int(line))
            else:
                if line == "ok":
                    Popup.SuccessfulBoot = True
                    Init.root.after(0,Popup.SystemBootPopup)
                elif line == "fejl":
                    Popup.SuccessfulBoot = False
                    Init.root.after(0,Popup.SystemBootPopup)
                elif line == "idle":
                    Init.root.after(0,Popup.SystemShutdownPopup)
                elif line == "sensor":
                    Init.root.after(0, Popup.SensorFail)
        except:
            pass
        
#Test funktion
'''def read_serial():
    global latest_value

    while True:
        try:
            line = ser.readline().decode('utf-8').strip()
            if line:
                print("Echo:", line)
                if line.isdigit():  # Only process pure numeric values
                    latest_value = int(line)
                    Init.root.after(0, home_page.update_power_callback, latest_value)
                else:
                    print("Arduino:", line)
        except Exception as e:
            print("Serial error:", e) '''
    
#Send serial:
def send_serial(data):
    try:    
        message = f"{data}\n"
        ser.write(message.encode('utf-8'))
        print("Sent:", message.strip())
    except:
        pass
            

