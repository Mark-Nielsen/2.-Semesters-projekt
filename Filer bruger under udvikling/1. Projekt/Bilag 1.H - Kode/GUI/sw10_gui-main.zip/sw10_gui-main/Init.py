import tkinter as tk

root = tk.Tk()
root.geometry('800x480')  # Vindue indstillinger
root.title('Power Management System')
root.configure(bg='#819171')

main_frame = tk.Frame(root, bg='#819171')
main_frame.pack_propagate(False)
main_frame.configure(width=660, height=420)
main_frame.place(x=140, y=80)


def ExitFullscreen():
    root.attributes('-fullscreen', False)