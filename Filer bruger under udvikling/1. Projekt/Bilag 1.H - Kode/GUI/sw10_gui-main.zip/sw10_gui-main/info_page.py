import tkinter as tk
import Init

def info_page():
    info_frame = tk.Frame(Init.main_frame, bg='#DFEAD6')
    info_frame.pack(fill="both", expand=True)
    
    label = tk.Label(
        info_frame,
        text="Information",
        font=('Arial', 20, 'bold'),
        bg='#DFEAD6'
    )
    label.pack(pady=20)
    
    with open("info.txt", "r", encoding="utf-8") as f:
        content = f.read()

    info_label = tk.Label(info_frame, text=content, font=('Bold', 12), bg='#DFEAD6')
    info_label.pack(padx=0, pady=10)

    #info_label.insert("1.0", content)