import tkinter as tk
from tkinter import messagebox
import Init

rooms = ["Room 1", "Room 2", "Room 3"]
profile_names = [f"Profile {i}" for i in range(1, 6)]

class Profile:
    def __init__(self, name):
        self.name = name
        self.rooms = {
            "Room 1": 0,
            "Room 2": 0,
            "Room 3": 0
        }

profiles = {
    profile_name: Profile(profile_name)
    for profile_name in profile_names
}

def get_profile_values(profile_name):
    profile = profiles[profile_name]

    return [
        profile.rooms[room]
        for room in rooms
    ]
    
#Gemmer de værdier brugeren indtaster
def save_profile(profile_name, temp_vars, status_label=None):
    profile = profiles[profile_name]
    
    for room, var in zip(rooms, temp_vars):
        value = var.get().replace("%", "")
        value = int(value)

    # gemmer værdien i objektet
        profile.rooms[room] = value

    if status_label is not None:
        status_label.config(text="Saved", fg="green")

# ----- overlay password page -----
def open_password(parent_frame, on_success):
    overlay = tk.Frame(parent_frame, bg='#DFEAD6')
    overlay.place(relx=0, rely=0, relwidth=1, relheight=1)

    overlay_box = tk.Frame(overlay, bg='#DFEAD6')
    overlay_box.place(relx=0.5, rely=0.5, anchor='center')

    enter_label = tk.Label(
        overlay_box,
        text="Enter password:",
        font=('Arial', 12, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    enter_label.pack(pady=(10,10))

    password_entry = tk.Entry(
        overlay_box,
        show="*",
        font=('Arial', 12, 'bold'),
        width=20,
    )
    password_entry.pack(pady=20)

    wrong_label = tk.Label(
        overlay_box,
        text="",
        font=('Arial', 12, 'bold'),
        bg='#DFEAD6',
        fg="red"
    )
    wrong_label.pack(pady=5)

    def check_password():
        if password_entry.get() == "1234":
            overlay.destroy()
            on_success()  # kalder save_data()
        else:
            wrong_label.config(text="Wrong password. Try again")

    confirm_button = tk.Button(
        overlay_box,
        text="Confirm",
        font=('Arial', 11, 'bold'),
        bg='#819171',
        fg='white',
        command=check_password
    )
    confirm_button.pack(pady=10)

    password_entry.focus_set()
    password_entry.bind("<Return>", lambda event: check_password())

# ----- Profil siderne -----
def profile_page(profile_name):
    profile_frame = tk.Frame(Init.main_frame, bg='#DFEAD6')
    profile_frame.pack(fill="both", expand=True)

    label = tk.Label(
        profile_frame,
        text=profile_name,
        font=('Arial', 20, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    label.pack(pady=20)

    status_label = tk.Label(
        profile_frame,
        text="",
        font=('Arial', 12, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    status_label.pack()

    profile = profiles[profile_name]

    temp_percent_vars = [
        tk.StringVar(value=str(profile.rooms[room]))
        for room in rooms
    ]

    for room, temp_var in zip(rooms, temp_percent_vars):
        room_label = tk.Label(
            profile_frame,
            text=room,
            font=('Arial', 12, 'bold'),
            bg='#DFEAD6',
            fg='#41431B'
        )
        room_label.pack(pady=(20, 2))

        percent_entry = tk.Entry(
            profile_frame,
            textvariable=temp_var,
            font=('Arial', 12, 'bold'),
            width=20,
            justify="center"
        )
        percent_entry.pack()

        percent_label = tk.Label(
            profile_frame,
            text="%",
            font=('Arial', 12, 'bold'),
            bg='#DFEAD6',
            fg='#41431B'
        )
        percent_label.pack()

    # Save-knap nederst til højre
    save_button = tk.Button(
        profile_frame,
        text="Save",
        font=('Arial', 11, 'bold'),
        bg='#819171',
        fg='white',
        command=lambda: (open_password(profile_frame, lambda: save_profile(profile_name, temp_percent_vars, status_label))
                         if all(
                             var.get().replace("%", "").isdigit() and 0 <= int(var.get().replace("%", "")) <= 100
                             for var in temp_percent_vars
                         )
                         else messagebox.showerror(
                             "Invalid input",
                             "All rooms must contain numbers between 0 and 100."
                         ))
    )
    
    save_button.place(relx=0.95, rely=0.93, anchor='se')