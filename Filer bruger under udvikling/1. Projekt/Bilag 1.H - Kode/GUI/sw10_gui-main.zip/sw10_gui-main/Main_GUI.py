import tkinter as tk
import Serial
import threading
import home_page
import profile_page
import info_page
import Init
import settings_page
import Popup

# ----------- Showing/deleting pages -----------
def delete_pages():
    for frame in Init.main_frame.winfo_children():
        frame.destroy()

def show_page(page):
    delete_pages()
    page()

# ----------- Titel and topbar -----------
title_label = tk.Label(Init.root, text='Power Management System', font=('Arial', 25, "bold"))
title_label.configure(
    background='#9CAF88',
    foreground='#f8f9f7',
    width=45,
    height=2,
)
title_label.place(x=-45, y=0)

button_frame = tk.Frame(Init.root, borderwidth=2, relief='groove', bg='#819171')
button_frame.place(x=0, y=80, width=140, height=420)
button_frame.grid_columnconfigure(0, weight=1)

# ---------- Buttons ------------
# Home button
home_btn = tk.Button(
    button_frame,
    text='Home',
    font=('Arial', 12),
    width=12,
    height=2,
    command=lambda: show_page(home_page.home_page)
)
home_btn.grid(row=0, column=0, padx=10, pady=4, sticky="ew")
home_btn.configure(activebackground='#41431B', activeforeground='white')

# Settings button
# Liste over profil knapper der bliver vist/skjult under settings
profile_buttons = []

is_settings_open = False
profiles = False

def settings_toggle():
    global is_settings_open, profiles
    is_settings_open = not is_settings_open

    # Opretter profilknapper
    if not profiles:
        for i in range(1, 6):
            profile_name = f"Profile {i}"

            profile_btn = tk.Button(
                button_frame,
                text=profile_name,
                font=('Arial', 12),
                width=12,
                height=1,
                command=lambda name=profile_name: show_page(
                    lambda: profile_page.profile_page(name)
                )
            )

            profile_btn.grid(row=i + 1, column=0, padx=10, pady=4, sticky="ew")
            profile_buttons.append(profile_btn)

        profiles = True

    # Hvis settings er åben, vis profiler
    if is_settings_open:
        for i, button in enumerate(profile_buttons, start=2):
            button.grid(row=i, column=0, padx=10, pady=4, sticky="ew")

        # Flytter eksisterende knapper
        settings_btn.grid(row=1, column=0, padx=10, pady=4, sticky="ew")
        info_btn.grid(row=7, column=0, padx=10, pady=4, sticky="ew")

    # Hvis settings lukkes, skjul profiler
    else:
        for button in profile_buttons:
            button.grid_remove()

        info_btn.grid(row=2, column=0, padx=10, pady=4, sticky="ew")

settings_btn = tk.Button(
    button_frame,
    text='Settings',
    font=('Arial', 12),
    width=12,
    height=2
)
settings_btn.grid(row=1, column=0, padx=10, pady=4, sticky="ew")
settings_btn.configure(command=lambda : (settings_toggle(), show_page(settings_page.settings_page)))
settings_btn.configure(activebackground='#41431B', activeforeground='white')

# Info button
info_btn = tk.Button(
    button_frame,
    text='Info',
    font=('Arial', 12),
    width=12,
    height=2,
    command=lambda: show_page(info_page.info_page)
)
info_btn.grid(row=2, column=0, padx=10, pady=4, sticky="ew")
info_btn.configure(activebackground='#41431B', activeforeground='white')

#Popup.SystemShutdownPopup() initer denne funktion hvis strøm vender tilbage til bygning og PMS dermed stopper.
Init.root.resizable(False, False)
show_page(home_page.home_page)
# Start thread
threading.Thread(target=Serial.read_serial, daemon=True).start()
#Popup.SystemBootPopup()
Init.root.attributes('-fullscreen', True)
Init.root.mainloop()