import tkinter as tk
import tkinter.ttk as ttk
import Init
import Serial
import profile_page

update_power_callback = 100
generatorStatus = 100

#Room status control 
RoomStatus = [True, False, False]   #[room1, room2, room3]

dropdown_options = profile_page.profile_names
chosen_profile = tk.StringVar(value=dropdown_options[0])

last_sent_profile = None

#Finder den profil brugeren vælger i dropdown -> sender til esp
def on_profile_change(event=None):
    global last_sent_profile
    selected_profile = chosen_profile.get()

    if selected_profile == last_sent_profile:
        return  # Don't re-send if nothing changed

    last_sent_profile = selected_profile
    room_values = profile_page.get_profile_values(selected_profile)
    values = ",".join(str(v) for v in room_values)
    Serial.send_serial(f"{selected_profile}|{values}\n")

#Bestemmer hvilke rum er aktive
def updateRoomStatus():
    selected_profile = chosen_profile.get()
    room_values = profile_page.get_profile_values(selected_profile)

    for i, value in enumerate(room_values):
        RoomStatus[i] = value <= generatorStatus
        
    return room_values

#Tæller hvor mange rum er aktive
def progressBarStatus():
    RoomProgress =0
    for i in range(3):
        if RoomStatus[i] == True:
            RoomProgress += 1
    return RoomProgress

# ----- Home page -----
def home_page():
    updateRoomStatus()
    home_frame = tk.Frame(Init.main_frame, bg='#DFEAD6')
    home_frame.pack(fill="both", expand=True)

    # -------- Øverste del -------
    top_frame = tk.Frame(home_frame, bg='#DFEAD6', height=140)
    top_frame.pack(fill="x")
    top_frame.pack_propagate(False)

    center_frame = tk.Frame(top_frame, bg='#DFEAD6')
    center_frame.place(relx=0.5, rely=0.5, anchor='center')

    home_label = tk.Label(
        center_frame,
        text="Currently active profile",
        font=('Arial', 18, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    home_label.pack(pady=(0, 15))

    profile_dropdown = ttk.Combobox(
        center_frame,
        textvariable=chosen_profile,
        width=20,
        font=('Arial', 12),
        state="readonly"
    )
    profile_dropdown["values"] = dropdown_options
    profile_dropdown.pack()

    # -------- Nederste del --------
    bottom_frame = tk.Frame(home_frame, bg='#DFEAD6')
    bottom_frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))

    bottom_frame.grid_columnconfigure(0, weight=1)
    bottom_frame.grid_columnconfigure(1, weight=0)
    bottom_frame.grid_rowconfigure(0, weight=1)

    # Venstre side
    left_frame = tk.Frame(bottom_frame, bg='#DFEAD6', bd=2)
    left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 30))

    # Højre side
    right_frame = tk.Frame(bottom_frame, bg='#DFEAD6', bd=2)
    right_frame.grid(row=0, column=1, sticky="nsew", padx=(30, 0))

    # ----- Active rooms progress bar -----
    rooms_label = tk.Label(
        right_frame,
        text="Active rooms",
        font=('Arial', 12, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    rooms_label.pack(pady=(20, 2))

    rooms_value_label = tk.Label(
        right_frame,
        text=f"{progressBarStatus()} / 3",
        font=('Arial', 11),
        bg='#DFEAD6',
        fg='black'
    )
    rooms_value_label.pack(pady=(0, 2))

    rooms_progress = ttk.Progressbar(
        right_frame,
        orient="horizontal",
        length=220,
        mode="determinate",
        maximum=3
    )
    rooms_progress.pack(pady=(0, 20))
    rooms_progress["value"] = progressBarStatus()

    # ----- Power level progress bar -----
    power_label = tk.Label(
        right_frame,
        text="Power level",
        font=('Arial', 12, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    power_label.pack(pady=(10, 2))

    power_value_label = tk.Label(
        right_frame,
        text="",  # % over progressbar
        font=('Arial', 11),
        bg='#DFEAD6',
        fg='black'
    )
    power_value_label.pack(pady=(0,2))

    power_progress = ttk.Progressbar(
        right_frame,
        orient="horizontal",
        length=220,
        mode="determinate",
        maximum=100
    )
    power_progress.pack(pady=(0, 20))

    # power_label og progressbar value er ens
    global update_power_callback
    def update_power(value):
        global generatorStatus
        value = max(0, min(100, int(value)))
        power_progress["value"] = value
        power_value_label.config(text=f"{value}%")
        generatorStatus = value
        refresh_home_status()
    update_power_callback = update_power

    # ----- Rooms activity levels -----
    rooms_title = tk.Label(
        left_frame,
        text="Rooms",
        font=('Arial', 16, 'bold'),
        bg='#DFEAD6',
        fg='#41431B'
    )
    rooms_title.pack(pady=(20, 20))

    # Container til rækker
    rooms_container = tk.Frame(left_frame, bg='#DFEAD6')
    rooms_container.pack()

    room_status_labels = []
    room_value_labels = []

    for row, room in enumerate(profile_page.rooms):
        room_label = tk.Label(
            rooms_container,
            text=room,
            font=('Arial', 12, 'bold'),
            bg='#DFEAD6',
        )
        room_label.grid(row=row, column=0, padx=10, pady=5, sticky="w")

        value_label = tk.Label(
            rooms_container,
            text="",
            font=('Arial', 12, 'bold'),
            bg='#DFEAD6',
            fg='#41431B'
        )
        value_label.grid(row=row, column=1, padx=10, pady=5)
        room_value_labels.append(value_label)

        status_label = tk.Label(
            rooms_container,
            text="",
            font=('Arial', 12),
            bg='#DFEAD6'
        )
        status_label.grid(row=row, column=2, padx=10, pady=5)
        room_status_labels.append(status_label)

    def refresh_home_status(event=None):
        on_profile_change()
        room_values = updateRoomStatus()
        active_rooms = progressBarStatus()

        rooms_value_label.config(text=f"{active_rooms} / {len(profile_page.rooms)}")
        rooms_progress["value"] = active_rooms

        for i, room in enumerate(profile_page.rooms):
            room_value_labels[i].config(text=f"{room_values[i]}%")
            if RoomStatus[i]:
                room_status_labels[i].config(text="Active", fg="green")
            else:
                room_status_labels[i].config(text="Inactive", fg="red")
    

    profile_dropdown.bind("<<ComboboxSelected>>", refresh_home_status)

    update_power(generatorStatus)
    refresh_home_status()
